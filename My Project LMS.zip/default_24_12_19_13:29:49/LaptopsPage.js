import React from 'react';
import CourseList from '../components/CourseList';

const LaptopsPage = () => {
  return (
    <div>
      <h1>Laptop Courses</h1>
      <CourseList category="Laptops" />
    </div>
  );
};

export default LaptopsPage;
