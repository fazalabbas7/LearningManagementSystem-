import React, { useEffect, useState } from 'react';

const AdminDashboard = () => {
  const [courses, setCourses] = useState([]);
  const [newCourse, setNewCourse] = useState({ title: '', description: '', category: '', price: '' });

  useEffect(() => {
    fetch('/api/courses')
      .then(response => response.json())
      .then(data => setCourses(data));
  }, []);

  const handleChange = (e) => {
    setNewCourse({ ...newCourse, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('/api/courses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newCourse),
    })
      .then(() => setNewCourse({ title: '', description: '', category: '', price: '' }))
      .then(() => fetch('/api/courses').then(res => res.json()).then(data => setCourses(data)));
  };

  return (
    <div>
      <h2>Admin Dashboard - Fazal Abbas</h2>
      <form onSubmit={handleSubmit}>
        <input name="title" value={newCourse.title} onChange={handleChange} placeholder="Course Title" required />
        <input name="description" value={newCourse.description} onChange={handleChange} placeholder="Description" required />
        <input name="category" value={newCourse.category} onChange={handleChange} placeholder="Category" required />
        <input name="price" value={newCourse.price} onChange={handleChange} placeholder="Price" required />
        <button type="submit">Add Course</button>
      </form>
      <h3>Existing Courses</h3>
      {courses.map(course => (
        <div key={course.id}>
          <h4>{course.title}</h4>
          <p>{course.description}</p>
        </div>
      ))}
    </div>
  );
};

export default AdminDashboard;
