import React, { useEffect, useState } from 'react';

const UserProfilePage = () => {
  const [user, setUser] = useState({ name: '', email: '', enrolledCourses: [] });

  useEffect(() => {
    fetch('/api/user-profile')
      .then(response => response.json())
      .then(data => setUser(data));
  }, []);

  return (
    <div>
      <h2>User Profile</h2>
      <p>Name: {user.name}</p>
      <p>Email: {user.email}</p>
      <h3>Enrolled Courses</h3>
      {user.enrolledCourses.map(course => (
        <div key={course.id}>
          <h4>{course.title}</h4>
        </div>
      ))}
    </div>
  );
};

export default UserProfilePage;
