import React, { useState } from 'react';

const EnrollmentForm = ({ courseId }) => {
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch(`/api/enroll`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ courseId, ...formData }),
    })
      .then(response => response.json())
      .then(data => setMessage(data.message))
      .catch(() => setMessage('Error in enrollment'));
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" value={formData.name} onChange={handleChange} placeholder="Name" required />
      <input name="email" value={formData.email} onChange={handleChange} placeholder="Email" required />
      <button type="submit">Enroll</button>
      {message && <p>{message}</p>}
    </form>
  );
};

export default EnrollmentForm;
