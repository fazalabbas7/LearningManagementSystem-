import React from 'react';
import CourseList from '../components/CourseList';

const SportsPage = () => {
  return (
    <div>
      <h1>Sports Courses</h1>
      <CourseList category="Sports" />
    </div>
  );
};

export default SportsPage;
