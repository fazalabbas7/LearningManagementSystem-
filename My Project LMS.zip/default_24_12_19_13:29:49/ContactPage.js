import React, { useState } from 'react';

const ContactPage = () => {
  const [contactInfo, setContactInfo] = useState({ name: '', email: '', subject: '', message: '' });

  const handleChange = (e) => {
    setContactInfo({ ...contactInfo, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(contactInfo),
    })
      .then(() => alert('Message sent successfully'))
      .catch(() => alert('Error sending message'));
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" value={contactInfo.name} onChange={handleChange} placeholder="Name" required />
      <input name="email" value={contactInfo.email} onChange={handleChange} placeholder="Email" required />
      <input name="subject" value={contactInfo.subject} onChange={handleChange} placeholder="Subject" required />
      <textarea name="message" value={contactInfo.message} onChange={handleChange} placeholder="Message" required />
      <button type="submit">Send</button>
    </form>
  );
};

export default ContactPage;
