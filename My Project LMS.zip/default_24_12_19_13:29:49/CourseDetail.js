import React, { useEffect, useState } from 'react';
import useFetch from '../hooks/useFetch';

const CourseDetail = ({ courseId }) => {
  const { data: course, loading, error } = useFetch(`/api/courses/${courseId}`);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error fetching course details</div>;

  return (
    <div>
      <h2>{course.title}</h2>
      <p>{course.description}</p>
      <h4>Instructor: {course.instructor}</h4>
      <button onClick={() => alert('Enrolled!')}>Enroll</button>
      <div>
        <h5>User Reviews</h5>
        {course.reviews.map(review => (
          <div key={review.id}>
            <p>{review.comment}</p>
            <p>Rating: {review.rating}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseDetail;
