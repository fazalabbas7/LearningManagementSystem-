import React from 'react';

const AboutPage = () => {
  return (
    <div>
      <h1>About Us</h1>
      <p>Our mission is to provide high-quality online courses.</p>
      <p>Developed by Fazal Abbas, Software Developer.</p>
    </div>
  );
};

export default AboutPage;
