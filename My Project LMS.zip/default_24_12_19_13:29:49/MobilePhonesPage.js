import React from 'react';
import CourseList from '../components/CourseList';

const MobilePhonesPage = () => {
  return (
    <div>
      <h1>Mobile Phone Courses</h1>
      <CourseList category="Mobile Phones" />
    </div>
  );
};

export default MobilePhonesPage;
