import React from 'react';
import CourseList from '../components/CourseList';

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to the Learning Management System</h1>
      <h2>Laptops</h2>
      <CourseList category="Laptops" />
      <h2>Sports</h2>
      <CourseList category="Sports" />
      <h2>Mobile Phones</h2>
      <CourseList category="Mobile Phones" />
    </div>
  );
};

export default HomePage;
