import React, { useEffect, useState } from 'react';
import useFetch from '../hooks/useFetch';

const CourseList = ({ category }) => {
  const { data: courses, loading, error } = useFetch(`/api/courses?category=${category}`);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error fetching courses</div>;

  return (
    <div>
      {courses.map(course => (
        <div key={course.id}>
          <h3>{course.title}</h3>
          <p>{course.description}</p>
          <a href={`/courses/${course.id}`}>View Details</a>
        </div>
      ))}
    </div>
  );
};

export default CourseList;
