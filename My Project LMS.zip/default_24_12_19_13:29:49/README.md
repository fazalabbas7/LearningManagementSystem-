# Learning Management System (LMS)

This is a Learning Management System (LMS) application developed by Fazal Abbas, Software Developer.

## Features

- User authentication (login)
- Course listing and detail views
- Enrollment in courses
- Admin dashboard for course management
- User profile management
- Contact form for support
- About page detailing the LMS

## Technologies Used

- React
- React Router
- CSS for styling

## Getting Started

### Prerequisites

- Node.js and npm installed on your machine.

### Installation

1. Clone the repository:
   