import React from 'react';

const ThankYouPage = () => {
  return (
    <div>
      <h1>Thank You for Enrolling!</h1>
      <p>Your enrollment was successful. We look forward to seeing you in the course!</p>
    </div>
  );
};

export default ThankYouPage;
